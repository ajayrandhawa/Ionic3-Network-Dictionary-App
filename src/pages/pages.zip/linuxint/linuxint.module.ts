import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { LinuxintPage } from './linuxint';

@NgModule({
  declarations: [
    LinuxintPage,
  ],
  imports: [
    IonicPageModule.forChild(LinuxintPage),
  ],
})
export class LinuxintPageModule {}

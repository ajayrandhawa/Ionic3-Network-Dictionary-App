import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { NetworkqaPage } from './networkqa';

@NgModule({
  declarations: [
    NetworkqaPage,
  ],
  imports: [
    IonicPageModule.forChild(NetworkqaPage),
  ],
})
export class NetworkqaPageModule {}

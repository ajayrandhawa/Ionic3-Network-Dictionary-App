import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { TechnicalspPage } from './technicalsp';

@NgModule({
  declarations: [
    TechnicalspPage,
  ],
  imports: [
    IonicPageModule.forChild(TechnicalspPage),
  ],
})
export class TechnicalspPageModule {}
